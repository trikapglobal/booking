package com.booking.service;

import com.booking.dao.ServiceDao;
import com.booking.entity.Service; // ✅ IMPORTANT IMPORT

import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Random;

// ✅ Use FULL PATH to avoid conflict
@org.springframework.stereotype.Service
@Transactional
public class ServiceService {

    private final ServiceDao serviceDao;
    private final Random random = new Random();

    // ✅ Constructor Injection
    public ServiceService(ServiceDao serviceDao) {
        this.serviceDao = serviceDao;
    }

    // ==============================
    // ✅ SAVE SERVICE
    // ==============================
    public String save(Service service) {

        if (service == null) return "Service is null";

        if (service.getName() == null || service.getName().trim().isEmpty()) {
            return "Service name is required";
        }

        // Duplicate check
        if (serviceDao.serviceExists(service.getName())) {
            return "Service already exists!";
        }

        // Generate UID
        if (service.getServiceuid() == null || service.getServiceuid().isEmpty()) {
            service.setServiceuid(generateServiceUID());
        }

        serviceDao.save(service);
        return "SUCCESS";
    }

    // ==============================
    // ✅ GET ALL SERVICES
    // ==============================
    public List<Service> getAllServices() {
        return serviceDao.getAllServices();
    }

    // ==============================
    // ✅ GET BY UID
    // ==============================
    public Service getByUid(String uid) {
        return serviceDao.getByUid(uid);
    }

    // ==============================
    // ✅ UPDATE SERVICE
    // ==============================
    public void update(Service service) {
        serviceDao.update(service);
    }

    // ==============================
    // ✅ DELETE SERVICE
    // ==============================
    public void delete(String uid) {
        serviceDao.delete(uid);
    }

    // ==============================
    // ✅ UID GENERATOR
    // ==============================
    private String generateServiceUID() {
        int length = 4;
        String numbers = "1234567890";
        StringBuilder uid = new StringBuilder();

        for (int i = 0; i < length; i++) {
            uid.append(numbers.charAt(random.nextInt(numbers.length())));
        }

        return "SRV" + uid.toString();
    }
}