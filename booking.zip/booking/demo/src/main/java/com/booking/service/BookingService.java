package com.booking.service;

import com.booking.dao.BookingDao;
import com.booking.entity.Booking;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

@Service
public class BookingService {

    private final BookingDao bookingDao;

    private final Random random = new Random();

    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public BookingService(BookingDao bookingDao) {
        this.bookingDao = bookingDao;
    }

    // =========================================================
    // SAVE BOOKING
    // =========================================================

    public String saveBooking(Booking booking,
                              String useruid,
                              String username) {

        // SERVICE VALIDATION

        if (booking.getServiceuid() == null ||
                booking.getServiceuid().isEmpty()) {

            return "Service not selected";
        }

        // DATE VALIDATION

        if (booking.getBookingdate() == null ||
                booking.getBookingdate().isEmpty()) {

            return "Select date";
        }

        // TIME SLOT VALIDATION

        if (booking.getTimeslot() == null ||
                booking.getTimeslot().isEmpty()) {

            return "Select time slot";
        }

        // SET VALUES

        booking.setUseruid(useruid);

        // ✅ SAVE USERNAME
        booking.setUsername(username);

        booking.setBookinguid(
                generateBookingUID()
        );

        booking.setStatus("PENDING");

        // SAVE TO DB

        bookingDao.save(booking);

        return "SUCCESS";
    }

    // =========================================================
    // GET BOOKINGS BY USER
    // =========================================================

    public List<Booking> getByUser(String useruid) {

        return bookingDao.getByUser(useruid);
    }

    // =========================================================
    // GET ALL BOOKINGS
    // =========================================================

    public List<Booking> getAllBookings() {

        return bookingDao.getAllBookings();
    }

    // =========================================================
    // UPDATE STATUS
    // =========================================================

    public void updateStatus(String uid,
                             String status) {

        bookingDao.updateStatus(uid, status);
    }

    // =========================================================
    // GENERATE BOOKING UID
    // =========================================================

    private String generateBookingUID() {

        int length = 4;

        String numbers = "1234567890";

        StringBuilder uid =
                new StringBuilder();

        for (int i = 0; i < length; i++) {

            uid.append(
                    numbers.charAt(
                            random.nextInt(
                                    numbers.length()
                            )
                    )
            );
        }

        return "BOOK" + uid;
    }
}