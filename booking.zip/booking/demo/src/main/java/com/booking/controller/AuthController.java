package com.booking.controller;

import com.booking.entity.Booking;
import com.booking.entity.User;
import com.booking.service.BookingService;
import com.booking.service.UserService;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private BookingService bookingService;

    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public AuthController(BookingService bookingService,
                          UserService userService) {

        this.bookingService = bookingService;
        this.userService = userService;
    }

    // =========================================================
    // REGISTER PAGE
    // =========================================================

    @GetMapping("/auth/register")
    public String showRegister(Model model) {

        model.addAttribute("user", new User());

        return "register";
    }

    // =========================================================
    // REGISTER USER
    // =========================================================

    @PostMapping("/auth/register")
    public String registerUser(@ModelAttribute("user") User user,
                               Model model) {

        String result = userService.register(user);

        if (!"SUCCESS".equals(result)) {

            model.addAttribute("error", result);

            return "register";
        }

        return "redirect:/auth/login";
    }

    // =========================================================
    // LOGIN PAGE
    // =========================================================

    @GetMapping("/auth/login")
    public String showLogin() {

        return "login";
    }

    // =========================================================
    // LOGIN USER
    // =========================================================

    @PostMapping("/auth/login")
    public String loginUser(@RequestParam String email,
                            @RequestParam String password,
                            @RequestParam String role,
                            Model model,
                            HttpSession session) {

        // LOGIN WITH ROLE CHECK

        User user = userService.login(email, password, role);

        // INVALID LOGIN

        if (user == null) {

            model.addAttribute("error",
                    "Invalid Email, Password or Role");

            return "login";
        }

        // STORE SESSION

        session.setAttribute("userName",
                user.getName());

        session.setAttribute("useruid",
                user.getUseruid());

        session.setAttribute("role",
                user.getRole());

        session.setAttribute("email",
                user.getEmail());

        // ROLE BASED REDIRECT

        if ("ADMIN".equalsIgnoreCase(user.getRole())) {

            return "redirect:/admin/dashboard";

        } else {

            return "redirect:/user/dashboard";
        }
    }

    // =========================================================
    // USER DASHBOARD
    // =========================================================

    @GetMapping("/user/dashboard")
    public String userDashboard(HttpSession session,
                                Model model) {

        String useruid =
                (String) session.getAttribute("useruid");

        String role =
                (String) session.getAttribute("role");

        // SESSION CHECK

        if (useruid == null) {

            return "redirect:/auth/login";
        }

        // ROLE CHECK

        if (!"USER".equalsIgnoreCase(role)) {

            return "redirect:/admin/dashboard";
        }

        // GET USER BOOKINGS

        List<Booking> bookings =
                bookingService.getByUser(useruid);

        model.addAttribute("bookings", bookings);

        return "user/dashboard";
    }

    // =========================================================
    // ADMIN DASHBOARD
    // =========================================================

    @GetMapping("/admin/dashboard")
    public String adminDashboard(HttpSession session,
                                 Model model) {

        // LOGIN CHECK

        if (session.getAttribute("useruid") == null) {

            return "redirect:/auth/login";
        }

        // ROLE CHECK

        String role =
                (String) session.getAttribute("role");

        if (!"ADMIN".equalsIgnoreCase(role)) {

            return "redirect:/user/dashboard";
        }

        // TOTAL USERS (ONLY USER ROLE)

        long totalUsers =
                userService.countUsersOnly();

        // TOTAL BOOKINGS

        long totalBookings =
                bookingService.getAllBookings().size();

        // RECENT BOOKINGS

        List<Booking> bookings =
                bookingService.getAllBookings();

        // MODEL DATA

        model.addAttribute("totalUsers",
                totalUsers);

        model.addAttribute("totalBookings",
                totalBookings);

        model.addAttribute("bookings",
                bookings);

        return "admin/dashboard";
    }

    // =========================================================
    // ADMIN USERS LIST
    // =========================================================

    @GetMapping("/admin/users")
    public String getAllUsers(Model model,
                              HttpSession session) {

        String role =
                (String) session.getAttribute("role");

        // ROLE CHECK

        if (role == null ||
                !"ADMIN".equalsIgnoreCase(role)) {

            return "redirect:/auth/login";
        }

        // GET ONLY NORMAL USERS

        List<User> users =
                userService.getUsersOnly();

        model.addAttribute("users",
                users);

        return "admin/user-list";
    }

    // =========================================================
    // USER PROFILE PAGE
    // =========================================================

    @GetMapping("/user/profile")
    public String userProfile(HttpSession session,
                              Model model) {

        String useruid =
                (String) session.getAttribute("useruid");

        String role =
                (String) session.getAttribute("role");

        // SESSION CHECK

        if (useruid == null) {

            return "redirect:/auth/login";
        }

        // ROLE CHECK

        if (!"USER".equalsIgnoreCase(role)) {

            return "redirect:/admin/dashboard";
        }

        // GET USER

        User user =
                userService.getByUid(useruid);

        model.addAttribute("user", user);

        return "user/profile";
    }

    // =========================================================
    // UPDATE USER PROFILE
    // =========================================================

    @PostMapping("/user/profile/update")
    public String updateUserProfile(
            @ModelAttribute("user") User user,
            HttpSession session,
            Model model
    ) {

        String useruid =
                (String) session.getAttribute("useruid");

        String role =
                (String) session.getAttribute("role");

        // SESSION CHECK

        if (useruid == null) {

            return "redirect:/auth/login";
        }

        // ROLE CHECK

        if (!"USER".equalsIgnoreCase(role)) {

            return "redirect:/admin/dashboard";
        }

        try {

            User existingUser =
                    userService.getByUid(useruid);

            if (existingUser == null) {

                return "redirect:/auth/login";
            }

            // UPDATE VALUES

            existingUser.setName(user.getName());

            existingUser.setEmail(user.getEmail());

            // PASSWORD UPDATE

            if (user.getPassword() != null &&
                    !user.getPassword().trim().isEmpty()) {

                existingUser.setPassword(
                        user.getPassword());
            }

            // KEEP ROLE

            existingUser.setRole("USER");

            // SAVE

            String result =
                    userService.updateProfile(existingUser);

            if (!"PROFILE_UPDATED".equals(result)) {

                model.addAttribute("error", result);

                model.addAttribute("user", existingUser);

                return "user/profile";
            }

            // UPDATE SESSION

            session.setAttribute("userName",
                    existingUser.getName());

            session.setAttribute("email",
                    existingUser.getEmail());

            model.addAttribute("success",
                    "Profile Updated Successfully");

            model.addAttribute("user",
                    existingUser);

            return "user/profile";

        } catch (Exception e) {

            model.addAttribute("error",
                    "Failed To Update Profile");

            model.addAttribute("user", user);

            return "user/profile";
        }
    }

    // =========================================================
    // ADMIN PROFILE PAGE
    // =========================================================

    @GetMapping("/admin/profile")
    public String adminProfile(HttpSession session,
                               Model model) {

        String useruid =
                (String) session.getAttribute("useruid");

        String role =
                (String) session.getAttribute("role");

        // SESSION CHECK

        if (useruid == null) {

            return "redirect:/auth/login";
        }

        // ROLE CHECK

        if (!"ADMIN".equalsIgnoreCase(role)) {

            return "redirect:/user/dashboard";
        }

        // GET ADMIN

        User user =
                userService.getByUid(useruid);

        model.addAttribute("user", user);

        return "admin/profile";
    }

    // =========================================================
    // UPDATE ADMIN PROFILE
    // =========================================================

    @PostMapping("/admin/profile/update")
    public String updateAdminProfile(
            @ModelAttribute("user") User user,
            HttpSession session,
            Model model
    ) {

        String useruid =
                (String) session.getAttribute("useruid");

        String role =
                (String) session.getAttribute("role");

        // SESSION CHECK

        if (useruid == null) {

            return "redirect:/auth/login";
        }

        // ROLE CHECK

        if (!"ADMIN".equalsIgnoreCase(role)) {

            return "redirect:/user/dashboard";
        }

        try {

            User existingUser =
                    userService.getByUid(useruid);

            if (existingUser == null) {

                return "redirect:/auth/login";
            }

            // UPDATE VALUES

            existingUser.setName(user.getName());

            existingUser.setEmail(user.getEmail());

            // PASSWORD UPDATE

            if (user.getPassword() != null &&
                    !user.getPassword().trim().isEmpty()) {

                existingUser.setPassword(
                        user.getPassword());
            }

            // KEEP ROLE

            existingUser.setRole("ADMIN");

            // SAVE

            String result =
                    userService.updateProfile(existingUser);

            if (!"PROFILE_UPDATED".equals(result)) {

                model.addAttribute("error", result);

                model.addAttribute("user", existingUser);

                return "admin/profile";
            }

            // UPDATE SESSION

            session.setAttribute("userName",
                    existingUser.getName());

            session.setAttribute("email",
                    existingUser.getEmail());

            model.addAttribute("success",
                    "Admin Profile Updated Successfully");

            model.addAttribute("user",
                    existingUser);

            return "admin/profile";

        } catch (Exception e) {

            model.addAttribute("error",
                    "Failed To Update Profile");

            model.addAttribute("user", user);

            return "admin/profile";
        }
    }

    // =========================================================
    // LOGOUT
    // =========================================================

    @GetMapping("/auth/logout")
    public String logout(HttpSession session) {

        session.invalidate();

        return "redirect:/auth/login";
    }
}