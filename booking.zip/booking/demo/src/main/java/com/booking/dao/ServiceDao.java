package com.booking.dao;

import com.booking.entity.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class ServiceDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // ✅ SAVE SERVICE
    public int save(Service service) {

        String sql = """
            INSERT INTO services 
            (serviceuid, name, description, price, insertdate, updatedate)
            VALUES (?, ?, ?, ?, ?, ?)
        """;

        LocalDateTime now = LocalDateTime.now();

        return jdbcTemplate.update(sql,
                service.getServiceuid(),
                service.getName(),
                service.getDescription(),
                service.getPrice(),
                now.toString(),
                now.toString()
        );
    }

    // ✅ GET ALL SERVICES
    public List<Service> getAllServices() {
        String sql = "SELECT * FROM services ORDER BY id DESC";
        return jdbcTemplate.query(sql, new ServiceRowMapper());
    }

    // ✅ GET SERVICE BY UID
    public Service getByUid(String serviceuid) {
        String sql = "SELECT * FROM services WHERE serviceuid = ?";
        return jdbcTemplate.queryForObject(sql, new ServiceRowMapper(), serviceuid);
    }

    // ✅ UPDATE SERVICE
    public int update(Service service) {

        String sql = """
            UPDATE services SET 
            name=?, description=?, price=?, updatedate=? 
            WHERE serviceuid=?
        """;

        return jdbcTemplate.update(sql,
                service.getName(),
                service.getDescription(),
                service.getPrice(),
                LocalDateTime.now().toString(),
                service.getServiceuid()
        );
    }

    // ✅ DELETE SERVICE
    public int delete(String serviceuid) {
        String sql = "DELETE FROM services WHERE serviceuid = ?";
        return jdbcTemplate.update(sql, serviceuid);
    }

    // ✅ ROW MAPPER
    private static class ServiceRowMapper implements RowMapper<Service> {

        @Override
        public Service mapRow(ResultSet rs, int rowNum) throws SQLException {

            Service s = new Service();

            s.setId(rs.getLong("id"));
            s.setServiceuid(rs.getString("serviceuid"));
            s.setName(rs.getString("name"));
            s.setDescription(rs.getString("description"));
            s.setPrice(rs.getString("price"));
            s.setInsertdate(rs.getString("insertdate"));
            s.setUpdatedate(rs.getString("updatedate"));

            return s;
        }
    }

    // ✅ CHECK SERVICE EXISTS (Optional Validation)
    public boolean serviceExists(String name) {
        String sql = "SELECT COUNT(*) FROM services WHERE LOWER(TRIM(name)) = LOWER(?)";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, name);
        return count != null && count > 0;
    }
}