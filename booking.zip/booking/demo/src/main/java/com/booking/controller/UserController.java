package com.booking.controller;

import com.booking.entity.Service;
import com.booking.service.ServiceService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class UserController {

    private final ServiceService serviceService;

    public UserController(ServiceService serviceService) {
        this.serviceService = serviceService;
    }

    // ✅ SHOW SERVICES TO USER
    @GetMapping("/user/services")
    public String userServices(Model model) {
        model.addAttribute("services", serviceService.getAllServices());
        return "user/services";
    }
}