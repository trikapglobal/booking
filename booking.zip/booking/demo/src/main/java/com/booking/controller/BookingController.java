package com.booking.controller;

import com.booking.entity.Booking;
import com.booking.entity.Service;
import com.booking.service.BookingService;
import com.booking.service.ServiceService;

import jakarta.servlet.http.HttpSession;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/booking")
public class BookingController {

    private final BookingService bookingService;

    private final ServiceService serviceService;

    // =========================================================
    // CONSTRUCTOR INJECTION
    // =========================================================

    public BookingController(BookingService bookingService,
                             ServiceService serviceService) {

        this.bookingService = bookingService;
        this.serviceService = serviceService;
    }

    // =========================================================
    // SHOW BOOKING FORM
    // =========================================================

    @GetMapping("/add/{serviceuid}")
    public String showBookingForm(@PathVariable String serviceuid,
                                  Model model) {

        Booking booking = new Booking();

        // SET SERVICE UID

        booking.setServiceuid(serviceuid);

        model.addAttribute("booking", booking);

        return "user/booking-form";
    }

    // =========================================================
    // SAVE BOOKING
    // =========================================================

    @PostMapping("/save")
    public String saveBooking(@ModelAttribute Booking booking,
                              HttpSession session,
                              Model model) {

        String useruid =
                (String) session.getAttribute("useruid");

        String username =
                (String) session.getAttribute("userName");

        // LOGIN CHECK

        if (useruid == null) {
            return "redirect:/auth/login";
        }

        // =====================================================
        // CONVERT TIME TO AM/PM
        // =====================================================

        try {

            String time24 =
                    booking.getTimeslot();

            LocalTime localTime =
                    LocalTime.parse(time24);

            DateTimeFormatter formatter =
                    DateTimeFormatter.ofPattern("hh:mm a");

            String formattedTime =
                    localTime.format(formatter);

            booking.setTimeslot(formattedTime);

        } catch (Exception e) {

            model.addAttribute("error",
                    "Invalid time format");

            return "user/booking-form";
        }

        // =====================================================
        // GET SERVICE DETAILS
        // =====================================================

        Service service =
                serviceService.getByUid(
                        booking.getServiceuid()
                );

        // SET SERVICE NAME

        if (service != null) {

            booking.setServicename(
                    service.getName()
            );
        }

        // =====================================================
        // SAVE BOOKING
        // =====================================================

        String result =
                bookingService.saveBooking(
                        booking,
                        useruid,
                        username
                );

        if (!"SUCCESS".equals(result)) {

            model.addAttribute("error",
                    result);

            return "user/booking-form";
        }

        return "redirect:/booking/list";
    }

    // =========================================================
    // MY BOOKINGS PAGE
    // =========================================================

    @GetMapping("/list")
    public String myBookings(HttpSession session,
                             Model model) {

        String useruid =
                (String) session.getAttribute("useruid");

        // LOGIN CHECK

        if (useruid == null) {
            return "redirect:/auth/login";
        }

        List<Booking> bookings =
                bookingService.getByUser(useruid);

        model.addAttribute("bookings",
                bookings);

        return "user/bookings";
    }
}