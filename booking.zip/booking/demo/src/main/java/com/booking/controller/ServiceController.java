package com.booking.controller;

import com.booking.entity.Service;
import com.booking.service.ServiceService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/services")
public class ServiceController {

    private final ServiceService serviceService;

    // ✅ Constructor Injection
    public ServiceController(ServiceService serviceService) {
        this.serviceService = serviceService;
    }

    // ===============================
    // ✅ LIST ALL SERVICES
    // ===============================
    @GetMapping
    public String listServices(Model model) {
        model.addAttribute("services", serviceService.getAllServices());
        return "admin/services"; // templates/admin/services.html
    }

    // ===============================
    // ✅ SHOW ADD FORM
    // ===============================
    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("service", new Service());
        return "admin/service-form";
    }

    // ===============================
    // ✅ SAVE SERVICE
    // ===============================
    @PostMapping("/save")
    public String saveService(@ModelAttribute("service") Service service, Model model) {

        String result = serviceService.save(service);

        if (!"SUCCESS".equals(result)) {
            model.addAttribute("error", result);
            return "admin/service-form";
        }

        return "redirect:/admin/services";
    }

    // ===============================
    // ✅ EDIT SERVICE
    // ===============================
    @GetMapping("/edit/{uid}")
    public String editService(@PathVariable String uid, Model model) {
        model.addAttribute("service", serviceService.getByUid(uid));
        return "admin/service-form";
    }

    // ===============================
    // ✅ UPDATE SERVICE
    // ===============================
    @PostMapping("/update")
    public String updateService(@ModelAttribute("service") Service service) {
        serviceService.update(service);
        return "redirect:/admin/services";
    }

    // ===============================
    // ✅ DELETE SERVICE
    // ===============================
    @GetMapping("/delete/{uid}")
    public String deleteService(@PathVariable String uid) {
        serviceService.delete(uid);
        return "redirect:/admin/services";
    }
}