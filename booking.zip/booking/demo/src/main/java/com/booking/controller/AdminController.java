package com.booking.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.booking.entity.Booking;
import com.booking.service.BookingService;
import com.booking.service.ServiceService;
import com.booking.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final BookingService bookingService ;
    private final ServiceService serviceService;
    private final UserService userService;

    public AdminController(BookingService bookingService,
                           ServiceService serviceService,
                           UserService userService) {
        this.bookingService = bookingService;
        this.serviceService = serviceService;
        this.userService = userService;
    }
    
    // ✅ Show all bookings
    @GetMapping("/bookings")
    public String viewBookings(Model model) {
        model.addAttribute("bookings", bookingService.getAllBookings());
        return "admin/bookings";
    }

    // ✅ Approve booking
    @GetMapping("/booking/approve/{uid}")
    public String approveBooking(@PathVariable String uid) {

        if (uid != null) {
            bookingService.updateStatus(uid, "APPROVED");
        }

        return "redirect:/admin/bookings";
    }

    // ❌ Reject booking
    // ✅ REJECT
    @GetMapping("/booking/reject/{uid}")
    public String rejectBooking(@PathVariable String uid) {
        if (uid != null) {
            bookingService.updateStatus(uid, "CANCELLED"); // consistent with UI
        }
        return "redirect:/admin/bookings";
    }
    
    @GetMapping("/admin/dashboard")
    public String adminDashboard(HttpSession session, Model model) {

        // ✅ Session check
        if (session.getAttribute("useruid") == null) {
            return "redirect:/auth/login";
        }

        // ✅ Role check
        String role = (String) session.getAttribute("role");
        if (!"ADMIN".equalsIgnoreCase(role)) {
            return "redirect:/user/dashboard";
        }

        // ✅ ADD THESE LINES HERE
        model.addAttribute("bookings", bookingService.getAllBookings());
        model.addAttribute("services", serviceService.getAllServices());
		/*
		 * model.addAttribute("totalUsers", userService.count());
		 * model.addAttribute("totalServices", serviceService.count());
		 * model.addAttribute("totalBookings", bookingService.count());
		 */

        return "admin/dashboard";
    }

}