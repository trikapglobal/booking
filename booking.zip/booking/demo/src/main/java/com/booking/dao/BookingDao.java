package com.booking.dao;

import com.booking.entity.Booking;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Repository
public class BookingDao {

    private final JdbcTemplate jdbcTemplate;

    // =========================================================
    // CONSTRUCTOR INJECTION
    // =========================================================

    public BookingDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // =========================================================
    // DATE FORMATTER
    // =========================================================

    private static final DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // =========================================================
    // SAVE BOOKING
    // =========================================================

    public int save(Booking booking) {

        String sql = """
            INSERT INTO bookings
            (
                bookinguid,
                useruid,
                username,
                serviceuid,
                servicename,
                bookingdate,
                timeslot,
                status,
                insertdate,
                updatedate
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """;

        String now =
                LocalDateTime.now().format(formatter);

        return jdbcTemplate.update(
                sql,

                booking.getBookinguid(),

                booking.getUseruid(),

                // ✅ SAVE USERNAME
                booking.getUsername(),

                booking.getServiceuid(),

                booking.getServicename(),

                booking.getBookingdate(),

                booking.getTimeslot(),

                booking.getStatus(),

                now,
                now
        );
    }

    // =========================================================
    // GET BOOKINGS BY USER
    // =========================================================

    public List<Booking> getByUser(String useruid) {

        String sql = """
            SELECT
                b.*,
                COALESCE(s.name, b.servicename) AS servicename
            FROM bookings b
            LEFT JOIN services s
                ON b.serviceuid = s.serviceuid
            WHERE b.useruid = ?
            ORDER BY b.bookingdate DESC
        """;

        return jdbcTemplate.query(
                sql,
                new BookingRowMapper(),
                useruid
        );
    }

    // =========================================================
    // GET ALL BOOKINGS
    // =========================================================

    public List<Booking> getAllBookings() {

        String sql = """
            SELECT
                b.*,
                COALESCE(s.name, b.servicename) AS servicename
            FROM bookings b
            LEFT JOIN services s
                ON b.serviceuid = s.serviceuid
            ORDER BY b.insertdate DESC
        """;

        return jdbcTemplate.query(
                sql,
                new BookingRowMapper()
        );
    }

    // =========================================================
    // UPDATE STATUS
    // =========================================================

    public void updateStatus(String uid,
                             String status) {

        String sql = """
            UPDATE bookings
            SET
                status = ?,
                updatedate = ?
            WHERE bookinguid = ?
        """;

        String now =
                LocalDateTime.now().format(formatter);

        jdbcTemplate.update(
                sql,
                status,
                now,
                uid
        );
    }

    // =========================================================
    // ROW MAPPER
    // =========================================================

    private static class BookingRowMapper
            implements RowMapper<Booking> {

        @Override
        public Booking mapRow(ResultSet rs,
                              int rowNum)
                throws SQLException {

            Booking b = new Booking();

            b.setId(
                    rs.getLong("id")
            );

            b.setBookinguid(
                    rs.getString("bookinguid")
            );

            b.setUseruid(
                    rs.getString("useruid")
            );

            // ✅ FETCH USERNAME
            b.setUsername(
                    rs.getString("username")
            );

            b.setServiceuid(
                    rs.getString("serviceuid")
            );

            b.setServicename(
                    rs.getString("servicename")
            );

            b.setBookingdate(
                    rs.getString("bookingdate")
            );

            b.setTimeslot(
                    rs.getString("timeslot")
            );

            b.setStatus(
                    rs.getString("status")
            );

            return b;
        }
    }
}