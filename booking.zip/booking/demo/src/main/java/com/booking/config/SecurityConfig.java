package com.booking.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
            // ❌ Disable CSRF (important for forms without token)
            .csrf(csrf -> csrf.disable())

            // ✅ Allow all requests (your custom auth will handle login)
            .authorizeHttpRequests(auth -> auth
                    .anyRequest().permitAll()
            )

            // ❌ Disable default login form
            .formLogin(form -> form.disable())

            // ❌ Disable HTTP basic popup
            .httpBasic(httpBasic -> httpBasic.disable());

        return http.build();
    }
}