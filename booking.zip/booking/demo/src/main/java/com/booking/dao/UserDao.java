package com.booking.dao;

import com.booking.entity.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class UserDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // =========================================================
    // ROW MAPPER
    // =========================================================

    private static class UserRowMapper implements RowMapper<User> {

        @Override
        public User mapRow(ResultSet rs, int rowNum)
                throws SQLException {

            User user = new User();

            user.setId(rs.getLong("id"));
            user.setUseruid(rs.getString("useruid"));
            user.setName(rs.getString("name")); // ✅ USERNAME
            user.setEmail(rs.getString("email"));
            user.setPassword(rs.getString("password"));
            user.setRole(rs.getString("role"));
            user.setInsertdate(rs.getString("insertdate"));
            user.setUpdatedate(rs.getString("updatedate"));

            return user;
        }
    }

    // =========================================================
    // SAVE USER
    // =========================================================

    public int save(User user) {

        String sql = """
            INSERT INTO users(
                useruid,
                name,
                email,
                password,
                role,
                insertdate,
                updatedate
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """;

        LocalDateTime now = LocalDateTime.now();

        return jdbcTemplate.update(
                sql,

                user.getUseruid(),
                user.getName(),
                user.getEmail(),
                user.getPassword(),

                user.getRole() == null
                        ? "USER"
                        : user.getRole().toUpperCase(),

                now.toString(),
                now.toString()
        );
    }

    // =========================================================
    // LOGIN USER BY EMAIL
    // =========================================================

    public User getUserByEmail(String email) {

        try {

            String sql = """
                SELECT * FROM users
                WHERE LOWER(TRIM(email)) = LOWER(TRIM(?))
            """;

            return jdbcTemplate.queryForObject(
                    sql,
                    new UserRowMapper(),
                    email.trim()
            );

        } catch (EmptyResultDataAccessException e) {

            return null;
        }
    }

    // =========================================================
    // GET ALL USERS
    // =========================================================

    public List<User> getAllUsers() {

        String sql = """
            SELECT *
            FROM users
            ORDER BY id DESC
        """;

        return jdbcTemplate.query(
                sql,
                new UserRowMapper()
        );
    }

    // =========================================================
    // GET ONLY NORMAL USERS
    // =========================================================

    public List<User> getAllNormalUsers() {

        String sql = """
            SELECT *
            FROM users
            WHERE UPPER(role) = 'USER'
            ORDER BY id DESC
        """;

        return jdbcTemplate.query(
                sql,
                new UserRowMapper()
        );
    }

    // =========================================================
    // TOTAL USER COUNT
    // =========================================================

    public int countUsersOnly() {

        String sql = """
            SELECT COUNT(*)
            FROM users
            WHERE UPPER(role) = 'USER'
        """;

        Integer count = jdbcTemplate.queryForObject(
                sql,
                Integer.class
        );

        return count == null ? 0 : count;
    }

    // =========================================================
    // TOTAL ADMIN COUNT
    // =========================================================

    public int countAdminsOnly() {

        String sql = """
            SELECT COUNT(*)
            FROM users
            WHERE UPPER(role) = 'ADMIN'
        """;

        Integer count = jdbcTemplate.queryForObject(
                sql,
                Integer.class
        );

        return count == null ? 0 : count;
    }

    // =========================================================
    // GET USER BY UID
    // =========================================================

    public User getByUid(String useruid) {

        try {

            String sql = """
                SELECT *
                FROM users
                WHERE useruid = ?
            """;

            return jdbcTemplate.queryForObject(
                    sql,
                    new UserRowMapper(),
                    useruid
            );

        } catch (EmptyResultDataAccessException e) {

            return null;
        }
    }

    // =========================================================
    // GET USER BY ID
    // =========================================================

    public User getUserById(Long id) {

        try {

            String sql = """
                SELECT *
                FROM users
                WHERE id = ?
            """;

            return jdbcTemplate.queryForObject(
                    sql,
                    new UserRowMapper(),
                    id
            );

        } catch (EmptyResultDataAccessException e) {

            return null;
        }
    }

    // =========================================================
    // GET USER NAME BY USER UID
    // =========================================================

    public String getUserNameByUid(String useruid) {

        try {

            String sql = """
                SELECT name
                FROM users
                WHERE useruid = ?
            """;

            return jdbcTemplate.queryForObject(
                    sql,
                    String.class,
                    useruid
            );

        } catch (EmptyResultDataAccessException e) {

            return "Unknown User";
        }
    }

    // =========================================================
    // UPDATE USER
    // =========================================================

    public int update(User user) {

        String sql = """
            UPDATE users
            SET
                name = ?,
                email = ?,
                password = ?,
                role = ?,
                updatedate = ?
            WHERE useruid = ?
        """;

        return jdbcTemplate.update(
                sql,

                user.getName(),
                user.getEmail(),
                user.getPassword(),
                user.getRole(),

                LocalDateTime.now().toString(),

                user.getUseruid()
        );
    }

    // =========================================================
    // UPDATE PROFILE
    // =========================================================

    public int updateProfile(User user) {

        String sql = """
            UPDATE users
            SET
                name = ?,
                email = ?,
                password = ?,
                updatedate = ?
            WHERE useruid = ?
        """;

        return jdbcTemplate.update(
                sql,

                user.getName(),
                user.getEmail(),
                user.getPassword(),

                LocalDateTime.now().toString(),

                user.getUseruid()
        );
    }

    // =========================================================
    // DELETE USER
    // =========================================================

    public int delete(String useruid) {

        String sql = """
            DELETE FROM users
            WHERE useruid = ?
        """;

        return jdbcTemplate.update(
                sql,
                useruid
        );
    }

    // =========================================================
    // EMAIL EXISTS
    // =========================================================

    public boolean emailExists(String email) {

        String sql = """
            SELECT COUNT(*)
            FROM users
            WHERE LOWER(TRIM(email)) = LOWER(TRIM(?))
        """;

        Integer count = jdbcTemplate.queryForObject(
                sql,
                Integer.class,
                email.trim()
        );

        return count != null && count > 0;
    }

    // =========================================================
    // GET USERS BY ROLE
    // =========================================================

    public List<User> getUsersByRole(String role) {

        String sql = """
            SELECT *
            FROM users
            WHERE UPPER(role) = UPPER(?)
            ORDER BY id DESC
        """;

        return jdbcTemplate.query(
                sql,
                new UserRowMapper(),
                role
        );
    }

    // =========================================================
    // COUNT USERS BY ROLE
    // =========================================================

    public long countUsersByRole(String role) {

        String sql = """
            SELECT COUNT(*)
            FROM users
            WHERE UPPER(role) = UPPER(?)
        """;

        Long count = jdbcTemplate.queryForObject(
                sql,
                Long.class,
                role
        );

        return count != null ? count : 0;
    }

    // =========================================================
    // USER UID EXISTS
    // =========================================================

    public boolean userUidExists(String useruid) {

        String sql = """
            SELECT COUNT(*)
            FROM users
            WHERE useruid = ?
        """;

        Integer count = jdbcTemplate.queryForObject(
                sql,
                Integer.class,
                useruid
        );

        return count != null && count > 0;
    }

}