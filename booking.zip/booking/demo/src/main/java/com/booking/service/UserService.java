package com.booking.service;

import com.booking.dao.UserDao;
import com.booking.entity.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    private final Random random = new Random();

    // =========================================================
    // AUTHENTICATE
    // =========================================================

    public boolean authenticate(String email,
                                String password) {

        if (email == null || password == null) {
            return false;
        }

        User user = userDao.getUserByEmail(
                email.trim().toLowerCase()
        );

        return user != null
                && user.getPassword() != null
                && user.getPassword().equals(password.trim());
    }

    // =========================================================
    // LOGIN WITH ROLE CHECK
    // =========================================================

    public User login(String email,
                      String password,
                      String role) {

        // VALIDATION

        if (email == null ||
                password == null ||
                role == null) {

            return null;
        }

        // GET USER

        User user = userDao.getUserByEmail(
                email.trim().toLowerCase()
        );

        // USER NOT FOUND

        if (user == null) {
            return null;
        }

        // PASSWORD CHECK

        if (user.getPassword() == null ||
                !user.getPassword().equals(password.trim())) {

            return null;
        }

        // ROLE CHECK

        if (user.getRole() == null ||
                !user.getRole().equalsIgnoreCase(role.trim())) {

            return null;
        }

        return user;
    }

    // =========================================================
    // GET USER BY EMAIL
    // =========================================================

    public User getUserByEmail(String email) {

        if (email == null ||
                email.trim().isEmpty()) {

            return null;
        }

        return userDao.getUserByEmail(
                email.trim().toLowerCase()
        );
    }

    // =========================================================
    // GET USER BY UID
    // =========================================================

    public User getByUid(String useruid) {

        if (useruid == null ||
                useruid.trim().isEmpty()) {

            return null;
        }

        try {

            return userDao.getByUid(useruid);

        } catch (Exception e) {

            return null;
        }
    }

    // =========================================================
    // GET ALL USERS
    // =========================================================

    public List<User> getAllUsers() {

        return userDao.getAllUsers();
    }

    // =========================================================
    // GET ONLY NORMAL USERS
    // =========================================================

    public List<User> getUsersOnly() {

        return userDao.getUsersByRole("USER");
    }

    // =========================================================
    // COUNT ONLY NORMAL USERS
    // =========================================================

    public long countUsersOnly() {

        return userDao.countUsersByRole("USER");
    }

    // =========================================================
    // REGISTER USER
    // =========================================================

    public String register(User user) {

        if (user == null) {
            return "User object is null";
        }

        // ================= NAME =================

        if (user.getName() == null ||
                user.getName().trim().isEmpty()) {

            return "Name is required";
        }

        user.setName(user.getName().trim());

        // ================= EMAIL =================

        if (user.getEmail() == null ||
                user.getEmail().trim().isEmpty()) {

            return "Email is required";
        }

        String email = user.getEmail()
                .trim()
                .toLowerCase();

        // DUPLICATE EMAIL CHECK

        if (userDao.emailExists(email)) {
            return "Email already exists";
        }

        user.setEmail(email);

        // ================= PASSWORD =================

        if (user.getPassword() == null ||
                user.getPassword().trim().isEmpty()) {

            return "Password is required";
        }

        if (!isStrongPassword(user.getPassword().trim())) {

            return "Password must contain upper, lower, number & special character";
        }

        user.setPassword(user.getPassword().trim());

        // ================= ROLE =================

        if (user.getRole() == null ||
                user.getRole().trim().isEmpty()) {

            user.setRole("USER");

        } else {

            user.setRole(
                    user.getRole()
                            .trim()
                            .toUpperCase()
            );
        }

        // ================= USER UID =================

        if (user.getUseruid() == null ||
                user.getUseruid().trim().isEmpty()) {

            String uid;

            do {

                uid = generateUserUID();

            } while (userDao.userUidExists(uid));

            user.setUseruid(uid);
        }

        // ================= SAVE USER =================

        int result = userDao.save(user);

        return result > 0
                ? "SUCCESS"
                : "FAILED";
    }

    // =========================================================
    // UPDATE PROFILE
    // =========================================================

    public String updateProfile(User user) {

        if (user == null) {
            return "User is null";
        }

        if (user.getUseruid() == null ||
                user.getUseruid().trim().isEmpty()) {

            return "Invalid user";
        }

        // GET EXISTING USER

        User existingUser;

        try {

            existingUser = userDao.getByUid(user.getUseruid());

        } catch (Exception e) {

            return "User not found";
        }

        if (existingUser == null) {
            return "User not found";
        }

        // ================= NAME =================

        if (user.getName() == null ||
                user.getName().trim().isEmpty()) {

            return "Name is required";
        }

        // ================= EMAIL =================

        if (user.getEmail() == null ||
                user.getEmail().trim().isEmpty()) {

            return "Email is required";
        }

        String email = user.getEmail()
                .trim()
                .toLowerCase();

        // EMAIL DUPLICATE CHECK

        User emailUser = userDao.getUserByEmail(email);

        if (emailUser != null &&
                !emailUser.getUseruid()
                        .equals(existingUser.getUseruid())) {

            return "Email already exists";
        }

        // ================= UPDATE VALUES =================

        existingUser.setName(
                user.getName().trim()
        );

        existingUser.setEmail(email);

        // PASSWORD UPDATE

        if (user.getPassword() != null &&
                !user.getPassword().trim().isEmpty()) {

            if (!isStrongPassword(user.getPassword().trim())) {

                return "Weak password format";
            }

            existingUser.setPassword(
                    user.getPassword().trim()
            );
        }

        // KEEP OLD ROLE

        existingUser.setRole(existingUser.getRole());

        // ================= UPDATE DATABASE =================

        int result = userDao.update(existingUser);

        return result > 0
                ? "PROFILE_UPDATED"
                : "UPDATE_FAILED";
    }

    // =========================================================
    // DELETE USER
    // =========================================================

    public void delete(String useruid) {

        if (useruid != null &&
                !useruid.trim().isEmpty()) {

            userDao.delete(useruid);
        }
    }

    // =========================================================
    // EMAIL EXISTS
    // =========================================================

    public boolean emailExists(String email) {

        if (email == null ||
                email.trim().isEmpty()) {

            return false;
        }

        return userDao.emailExists(
                email.trim().toLowerCase()
        );
    }

    // =========================================================
    // PASSWORD VALIDATION
    // =========================================================

    private boolean isStrongPassword(String password) {

        if (password == null) {
            return false;
        }

        return password.matches(
                "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&]).{8,}$"
        );
    }

    // =========================================================
    // GENERATE USER UID
    // =========================================================

    private String generateUserUID() {

        String numbers = "1234567890";

        StringBuilder uid = new StringBuilder();

        for (int i = 0; i < 4; i++) {

            uid.append(
                    numbers.charAt(
                            random.nextInt(numbers.length())
                    )
            );
        }

        return "USR" + uid;
    }
}